




-------------------How to run the demo mobile app------------------------------------

1. First open chrome, then go to click on the drop down link icon to show more options. 
2. Go to more tools, then click on extensions. 
3. Then open chrome web store and search for Ripple Emulator (Beta). 
4. Add extension to the browser.
5. Enable the ripple emulator.
6. Then run the index file to demostrate the app.

                            Alternatively

For better demostration upload the zipped folder to www.phonegap.com to deploy the
application as a mobile app with different version tastes of Windows Phone, Android 
and iPhone.
1. Open www.phonegap.com
2. Scroll down to find phonegap build
3. Sign in
4. Find upload then build to produce apk file to install to android phone.
---------------------------------------------------------------------------------------
